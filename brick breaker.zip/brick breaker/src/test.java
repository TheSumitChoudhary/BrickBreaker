import javax.swing.JFrame;
import javax.swing.Timer;
import java.awt.color.*;
import java.awt.Graphics;

import java.awt.*;

public class test {

	public static void main(String args[])
	{

		Gameplay gamePlay = new Gameplay();
		
		JFrame obj = new JFrame();
		obj.setBounds(10,10,700,600);
		obj.setTitle("Brick Breaker");
		
		obj.setResizable(false);
		
		obj.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		obj.add(gamePlay);
		obj.setVisible(true);
	
	}
}